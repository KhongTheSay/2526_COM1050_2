package TranDucManh_25020258_Week4.Bai04.src;
interface IData {
    public abstract void show();
}
class DataManager implements IData {
    @Override
    public void show (){
        System.out.println("Show Data ");
    }
}

public class chap4 {
    public static void main (String [] args ){
        DataManager a = new DataManager();
        a.show();
    }
}