package TranDucManh_25020258_Week8.Bai01.src;

public class Calculator {
    private static final double DISCOUNT = 0.9;

    public double calculate(int hours, double rate, boolean member) {
        double fee = hours * rate;
        if (member) {
            fee *= DISCOUNT;
        }
        return fee;=
    }
}



abstract class Area(){
    double a, b;
    Area(double a, double b) { this.a = a; this.b = b; }
    abstract double getArea(double a , double b )
}
class Triangle extends Area{
    Triangle(double a, double b) { super(a, b); }
    @Override
    double getArea(){ return a*b*0,5;}
}
class Rectangle extends Area{
    Rectangle(double a, double b) { super(a, b); }
    @Override
    double getArea(){ return a*b;}
}
class Circle extends Area{
    Circle(double a ,0) { super(a, 0); }
    @Override
    double getArea(){ return 3.141569*a*a;}
}
class Other extends Area {
    return -1;
}



class user(){
    private String title ;
    private String content ;
}
class inforuser(){
    private authorEmail ;
    private String authorName ;
    private String authorPhone ;
    private String authorAdress;
}



class information{
    public User finbyId(int id ){}
}
class sendInfor{
    public void sendWelcomeEmail(User user ){}
    public void  sendPasswordResetEmail(User user){}
}
class display{
    public void renderUserProfile(User user){}
}
class export {
    public exportUserToCsv(User user){}
}




public class chap1 {
    public static void main(String[] args) {
        System.out.println("Hello from chap1");
    }
}
